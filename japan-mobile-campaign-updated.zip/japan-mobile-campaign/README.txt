JAPAN MOBILE CAMPAIGN WEBSITE
1. Open index.html in Chrome.
2. Choose one of 8 languages from the top menu.
3. Phone number is 080-7741-9664. Address is Nishikebukuro 1-19-6, Toshima-ku, Tokyo.
4. Facebook URL was not provided; replace placeholder once known.
5. The inquiry form opens a mail draft WITHOUT a destination address. It does NOT send submissions to the owner. For real inquiries, connect a secure form backend or form service with consent and spam protection.
6. Cashback and eligibility must be checked against official campaign terms before publication. The website is not an official telecom carrier site.
